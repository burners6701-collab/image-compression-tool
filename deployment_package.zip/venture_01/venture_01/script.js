document.getElementById('compress-btn').addEventListener('click', function() {
    const fileInput = document.getElementById('file-input');
    const outputContainer = document.getElementById('images');
    outputContainer.innerHTML = '';  // Clear previous images

    for (const file of fileInput.files) {
        const reader = new FileReader();
        reader.onload = function(event) {
            const img = new Image();
            img.src = event.target.result;
            img.onload = function() {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                const MAX_WIDTH = 800;
                const scaleSize = MAX_WIDTH / img.width;
                canvas.width = MAX_WIDTH;
                canvas.height = img.height * scaleSize;
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                const dataUrl = canvas.toDataURL('image/jpeg', 0.7);  // Compress

                const compressedImage = new Image();
                compressedImage.src = dataUrl;
                outputContainer.appendChild(compressedImage);
            };
        };
        reader.readAsDataURL(file);
    }
});